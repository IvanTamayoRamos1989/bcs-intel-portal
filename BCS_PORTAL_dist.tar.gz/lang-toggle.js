(function () {
  var KEY = 'bcs_portal_lang';
  function apply(lang) {
    document.documentElement.setAttribute('lang', lang);
    document.documentElement.setAttribute('data-lang', lang);
    document.querySelectorAll('[data-lang-es]').forEach(function (el) {
      el.hidden = lang !== 'es';
    });
    document.querySelectorAll('[data-lang-en]').forEach(function (el) {
      el.hidden = lang !== 'en';
    });
    document.querySelectorAll('[data-i18n]').forEach(function (el) {
      var k = el.getAttribute('data-i18n');
      var dict = window.__BCS_UI__ && window.__BCS_UI__[lang];
      if (dict && dict[k] != null) {
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
          el.setAttribute('placeholder', dict[k]);
        } else {
          el.textContent = dict[k];
        }
      }
    });
    var btn = document.getElementById('lang-toggle');
    if (btn) {
      btn.setAttribute('aria-pressed', lang === 'en' ? 'true' : 'false');
      btn.querySelector('[data-side=es]')?.classList.toggle('active', lang === 'es');
      btn.querySelector('[data-side=en]')?.classList.toggle('active', lang === 'en');
    }
    try { localStorage.setItem(KEY, lang); } catch (e) {}
  }
  function current() {
    try {
      var s = localStorage.getItem(KEY);
      if (s === 'en' || s === 'es') return s;
    } catch (e) {}
    return 'es';
  }
  document.addEventListener('DOMContentLoaded', function () {
    apply(current());
    var btn = document.getElementById('lang-toggle');
    if (btn) {
      btn.addEventListener('click', function () {
        apply(current() === 'es' ? 'en' : 'es');
      });
    }
  });
  window.__BCS_SET_LANG__ = apply;
})();
